package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import persistence.Reader;
import persistence.Writer;

import java.io.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class WalletTest {
    Wallet wallet;

    @BeforeEach
    void RunBefore(){
        wallet = new Wallet("Max", 100);
    }

    @Test
    void TestConstructor(){
        assertEquals("Max", wallet.getName());
        assertEquals(100, wallet.getBalance());
    }

    @Test
    void TestWelcomePrompt(){
        assertEquals("Welcome back, Max!", wallet.welcomePrompt());
    }

    @Test
    void TestSetBalance(){
        wallet.setBalance(2000);
        assertEquals(2000, wallet.getBalance());
    }

    @Test
    void TestSetName(){
        wallet.setName("Maximus");
        assertEquals("Maximus", wallet.getName());
    }

    @Test
    void TestChangeBalance(){
        wallet.changeBalance("Win");
        assertEquals(110, wallet.getBalance());
        wallet.changeBalance("Lose");
        assertEquals(100, wallet.getBalance());
        wallet.changeBalance("wrong");
        assertEquals(100, wallet.getBalance());
    }

    @Test
    void TestSave() throws FileNotFoundException, UnsupportedEncodingException {
        Writer writer = new Writer(new File("./data/testSave.txt"));
        writer.write(wallet);
        writer.close();

        try {
            Wallet savedWallet = Reader.readSave(new File("./data/testSave.txt"));
            assertEquals("Max", savedWallet.getName());
            assertEquals(100, savedWallet.getBalance());

        } catch (IOException e) {
            fail("IOException was not supposed to be caught");
        }

    }
}
