package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CardTest {
    private Card card;

    @BeforeEach
    void RunBefore() {
        card = new Card();
    }

    @Test
    void testConstructor() {
        assertTrue(card.getSuit() <= 4);
        assertTrue(card.getCardNumber() <= 13);
        if(card.getCardNumber() < 10) {
            assertEquals(card.getCardNumber(), card.getValue());
        } else {
            assertEquals(10, card.getValue());
        }
    }

    @Test
    void testGetSuitString() {
        card.setSuit(1);
        assertEquals("Hearts", card.getSuitString());
        card.setSuit(2);
        assertEquals("Diamonds", card.getSuitString());
        card.setSuit(3);
        assertEquals("Spades", card.getSuitString());
        card.setSuit(4);
        assertEquals("Clubs", card.getSuitString());
        card.setSuit(5);
        assertEquals("ERROR- NUM OUT OF RANGE", card.getSuitString());
    }

    @Test
    void testGetCardString() {
        card.setCardNumber(1);
        assertEquals("A", card.getCardString());
        card.setCardNumber(11);
        assertEquals("J", card.getCardString());
        card.setCardNumber(12);
        assertEquals("Q", card.getCardString());
        card.setCardNumber(13);
        assertEquals("K", card.getCardString());
        card.setCardNumber(14);
        assertEquals("ERROR- NUM OUT OF RANGE", card.getCardString());
        for(int i=2; i < 11; i++) {
            card.setCardNumber(i);
            assertEquals(Integer.toString(i), card.getCardString());
        }
    }

}
