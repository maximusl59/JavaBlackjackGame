package model;

import exceptions.BlownUpException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class HandTest {
    Hand hand;

    @BeforeEach
    void RunBefore() {
        hand = new Hand();
    }

    @Test
    void testDrawCard() {
        try {
            hand.drawCard();
        } catch (BlownUpException e) {
            fail();
        }
        assertEquals(1,hand.cardList.size());
    }

    @Test
    void testBlownUp() {
        hand.setTotal(21);
        try{
            hand.drawCard();
            fail();
        } catch (BlownUpException e) {
            //expected
        }
    }

    @Test
    void testInitializeHand() {
        hand.initializeHand();
        assertEquals(2, hand.cardList.size());
    }

    @Test
    void testGetTotal() {
        hand.initializeHand();
        int actualValue = hand.cardList.get(0).getValue() + hand.cardList.get(1).getValue();
        assertEquals(actualValue, hand.getTotal());
    }

    @Test
    void testGetCardInList() {
        try {
            hand.drawCard();
        } catch (BlownUpException e) {
            fail();
        }
        assertEquals(hand.cardList.get(0), hand.getCardInList(0));
    }

    @Test
    void testToString() {
        try {
            hand.drawCard();
        } catch (BlownUpException e) {
            fail();
        }
        hand.cardList.get(0).setSuit(1);
        hand.cardList.get(0).setCardNumber(1);
        assertEquals("A of Hearts",
                hand.toString(hand.getCardInList(0)));
    }
}
