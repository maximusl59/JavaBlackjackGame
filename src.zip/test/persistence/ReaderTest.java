package persistence;

import model.Wallet;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class ReaderTest {

    private Reader reader;

    @BeforeEach
    void RunBefore(){
        reader = new Reader();
    }

    @Test
    void parseReaderTestSave1() {
        try {
            Wallet testWallet = reader.readSave(new File("./data/readerTestSave1.txt"));
            assertEquals("Emmanuel", testWallet.getName());
            assertEquals(30, testWallet.getBalance());

        } catch(IOException e){
            fail("Exception should not have been thrown");
        }
    }

    @Test
    void parseReaderTestSave2() {
        try {
            Wallet testWallet = reader.readSave(new File("./data/readerTestSave2.txt"));
            assertEquals("Chanel", testWallet.getName());
            assertEquals(2000, testWallet.getBalance());

        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    void IOException() throws IOException {
        try {
            Wallet wallet = reader.readSave(new File("./data/not/real/path.txt"));
        } catch (IOException e) {
            //exception meant to be caught
        }
    }
}