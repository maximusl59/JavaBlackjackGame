package persistence;

import model.Wallet;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import static org.junit.jupiter.api.Assertions.*;

public class WriterTest {
    private static final String SAVE_LOCATION = "./data/testSave.txt";
    private Writer writer;
    private Wallet wallet;

    @BeforeEach
    void RunBefore() throws FileNotFoundException, UnsupportedEncodingException {
        writer = new Writer(new File(SAVE_LOCATION));
        wallet = new Wallet("Max", 100);
    }

    @Test
    void TestWriteSave(){
        writer.write(wallet);
        writer.close();

        try {
            Wallet savedWallet = Reader.readSave(new File(SAVE_LOCATION));
            assertEquals("Max", savedWallet.getName());
            assertEquals(100, savedWallet.getBalance());

        } catch (IOException e) {
            fail("IOException was not supposed to be caught");
        }

    }

}
