package model;

import persistence.Reader;
import persistence.Saveable;

import java.io.PrintWriter;

//represents a wallet containing an amount of balance and a player's name
public class Wallet implements Saveable {
    private String name;
    private int balance;

    //MODIFIES: this
    //EFFECTS: creates a wallet with given player's name and balance
    public Wallet(String playerName, int givenBalance) {
        name = playerName;
        balance = givenBalance;
    }

    //EFFECTS: returns string for welcome back dialogue
    public String welcomePrompt() {
        return "Welcome back, " + name + "!";
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int givenBalance) {
        balance = givenBalance;
    }

    public String getName() {
        return name;
    }

    public void setName(String playerName) {
        name = playerName;
    }

    //MODIFIES: this
    //EFFECTS: adds or subtracts 10 currency depending on if player won or lost
    public void changeBalance(String status) {
        if (status.equals("Win")) {
            balance += 10;
        } else if (status.equals("Lose")) {
            balance -= 10;
        } else {
            balance += 0;
        }
    }

    //EFFECTS: saves saveable data to a file
    @Override
    public void save(PrintWriter printWriter) {
        printWriter.print(name);
        printWriter.print(Reader.DELIMITER);
        printWriter.print(balance);
    }


}
