package model;

import java.util.List;
import java.util.Random;

//Represents a card with a suit, number and in-game value
public class Card {
    private int suit;
    private int cardNumber;
    private int value;

    //MODIFIES: this
    //EFFECTS: constructs a new card with integer "suit" from 1 to 4 representing the card's suit
    //         and cardNumber from 1 to 13 representing the number on the card. it sets the card's
    //         value depending on the card number and how that card is valued in the game.
    //         (I found the Random function on geeksforgeeks.org)
    public Card() {
        Random random = new Random();

        suit = random.nextInt(4) + 1;
        cardNumber = random.nextInt(13) + 1;
        if (cardNumber > 10) {
            value = 10;
        } else {
            value = cardNumber;
        }
    }

    //EFFECTS: converts suit value to suit name and returns it
    public String getSuitString() {
        String suitName;
        switch (suit) {
            case 1:
                suitName = "Hearts";
                break;
            case 2:
                suitName = "Diamonds";
                break;
            case 3:
                suitName = "Spades";
                break;
            case 4:
                suitName = "Clubs";
                break;
            default:
                suitName = "ERROR- NUM OUT OF RANGE";
        }
        return suitName;
    }

    //EFFECTS: converts card number to string. if card is 1, 11, 12 or 13, names as A, J, Q and K.
    //         (Integer.toString was found on geeksforgeeks.org)
    public String getCardString() {
        String cardName;
        if (cardNumber > 1 && cardNumber < 11) {
            return Integer.toString(cardNumber);
        } else {
            switch (cardNumber) {
                case 1:
                    cardName = "A";
                    break;
                case 11:
                    cardName = "J";
                    break;
                case 12:
                    cardName = "Q";
                    break;
                case 13:
                    cardName = "K";
                    break;
                default:
                    cardName = "ERROR- NUM OUT OF RANGE";
            }
            return cardName;
        }
    }

    public int getSuit() {
        return suit;
    }

    public int getCardNumber() {
        return cardNumber;
    }

    public int getValue() {
        return value;
    }

    public void setSuit(int number) {
        this.suit = number;
    }

    public void setCardNumber(int number) {
        this.cardNumber = number;
    }

}
