package model;

import exceptions.BlownUpException;

import java.util.ArrayList;

//represents a hand that can contain some list of cards
public class Hand {
    public ArrayList<Card> cardList;
    int total;

    //MODIFIES: this
    //EFFECTS: constructs a new hand with card list
    public Hand() {
        cardList = new ArrayList<>();
    }

    //MODIFIES: this
    //EFFECTS: gets a new card and adds the card to hand and throws blown up exception if total is greater than 21
    public void drawCard() throws BlownUpException {
        Card card = new Card();
        cardList.add(card);
        total += card.getValue();
        if (total > 21) {
            throw new BlownUpException();
        }
    }

    //MODIFIES: this
    //EFFECTS: adds two cards to hand
    public void initializeHand() {
        for (int i = 1; i <= 2; i++) {
            Card card = new Card();
            cardList.add(card);
            total += card.getValue();
        }
    }

    //EFFECTS: returns a description of the card the dealer picks up
    public String toString(Card card) {
        String result = card.getCardString()
                + " of " + card.getSuitString();
        return result;
    }

    public void setTotal(int number) {
        total = number;
    }

    public int getTotal() {
        return total;
    }

    public Card getCardInList(int number) {
        return cardList.get(number);
    }
}
