package persistence;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

//used for writing saved data to a txt file
public class Writer {
    private PrintWriter printWriter;

    //EFFECTS: initializes a new writer to write data to save file
    public Writer(File file) throws FileNotFoundException, UnsupportedEncodingException {
        printWriter = new PrintWriter(file, "UTF-8");
    }

    //MODIFIES: this
    //EFFECTS: passes saveable data to printwriter to save to txt file
    public void write(Saveable saveable) {
        saveable.save(printWriter);
    }

    //MODIFIES: this
    //EFFECTS: closes writer
    public void close() {
        printWriter.close();
    }
}
