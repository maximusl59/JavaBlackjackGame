package persistence;

import model.Wallet;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

//used for loading saved data from txt file
public class Reader {
    public static final String DELIMITER = ",";

    //EFFECTS: reads file and organizes components of the file to return as components of a wallet
    public static Wallet readSave(File file) throws IOException {
        String fileData = Files.readAllLines(file.toPath()).get(0);
        String[] components = fileData.split(DELIMITER);
        List<String> componentsArray = Arrays.asList(components);
        String name = componentsArray.get(0);
        int currentBalance = Integer.parseInt(componentsArray.get(1));
        return new Wallet(name, currentBalance);
    }
}
