package persistence;

import java.io.PrintWriter;

//represents data that can be saved
public interface Saveable {

    //MODIFIES: printWriter
    //EFFECTS: writes saveable data to printwriter to write to txt file
    void save(PrintWriter printWriter);
}
