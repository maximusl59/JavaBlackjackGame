package ui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;

import java.io.IOException;

//Start Menu Scene
public class StartMenuController extends Menu {

    @FXML Button start;
    @FXML Button instructionsButton;
    @FXML Button quitButton;
    @FXML Button newGameButton;

    //MODIFIES: this
    //EFFECTS: creates a blackjack game and attempts to load pre-existing wallet, if not found prompt to make new one
    public void init() {
        walletManager = new WalletManager();

        try {
            walletManager.loadWallet();
            update();

        } catch (IOException e) {
            newSave();
        }
    }

    //EFFECTS: loads next game window
    //source: https://www.youtube.com/watch?v=SGZUQvuqL5Q (pass data between scenes)
    @FXML
    void runGame(MouseEvent event) throws IOException {
        super.runGame(event);
    }

    //EFFECTS: opens window with instructions on it
    @FXML
    void instructions(MouseEvent event) {
        super.instructions(event);
    }

    //EFFECTS: quits game
    @FXML
    void quit(MouseEvent event) {
        super.quit(event);
    }

    //EFFECTS: provides warning screen and initiates a new save call
    @FXML
    void newGameButtonFunction(MouseEvent event) {
        super.newGameButtonFunction(event);
    }
}
