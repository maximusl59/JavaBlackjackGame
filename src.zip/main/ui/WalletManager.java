package ui;

import model.Wallet;
import persistence.Reader;
import persistence.Writer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;


//saves and loads the wallet
public class WalletManager {

    private static final String SAVE_FILE = "./data/save.txt";
    protected Wallet wallet;

    public WalletManager() {
    }

    //MODIFIES: this
    //EFFECTS: loads an existing wallet to game but if none exists, creates a new wallet
    protected void loadWallet() throws IOException {
        wallet = Reader.readSave(new File(SAVE_FILE));
    }

    //EFFECTS: saves current wallet state to the save file.
    protected void saveWallet() {
        try {
            Writer writer = new Writer(new File(SAVE_FILE));
            writer.write(wallet);
            writer.close();
        } catch (FileNotFoundException e) {
            System.out.println("Failed to save");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

    }

    //MODIFIES: this
    //EFFECTS: Initializes a new wallet based on name input and starting currency
    protected void init(String name) {
        wallet = new Wallet(name, 100);
        saveWallet();
    }

}
