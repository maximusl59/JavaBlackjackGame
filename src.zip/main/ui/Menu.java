package ui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Optional;

public abstract class Menu {

    private static final String INTRO_TEXT = "Welcome to Blackjack! \n"
            + "The aim of the game is to draw cards that add up to a greater "
            + "number than the dealer but does not exceed 21. Each card is "
            + "valued off of the actual card number with A being 1 "
            + "and J, Q and K all being 10s.";

    @FXML Text nameText;
    @FXML Text balanceText;

    WalletManager walletManager;

    //MODIFIES: this
    //EFFECTS: updates name and balance
    void update() {
        nameText.setText("Name: " + walletManager.wallet.getName());
        balanceText.setText("Balance: " + walletManager.wallet.getBalance());
    }

    //MODIFIES: this
    //EFFECTS: asks player to input a name and saves name to game files
    //source: https://code.makery.ch/blog/javafx-dialogs-official/ (Alerts/Dialogues)
    void newSave() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("");
        dialog.setHeaderText("Important:");
        dialog.setContentText("Please enter your name:");

        Optional<String> result;

        do {
            result = dialog.showAndWait();
        } while (result.get().equals("") || !result.isPresent());

        if (result.get().equals("tobs")) {
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            Image image = null;
            try {
                image = new Image(new FileInputStream("./data/tobs.jpg"));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            a.setGraphic(new ImageView(image));
            a.showAndWait();
        }

        walletManager.init(result.get());
        update();
    }

    //EFFECTS: loads next game window
    @FXML
    void runGame(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("GameWindow.fxml"));
        Parent root = (Parent) loader.load();
        Scene scene = new Scene(root);

        Stage primaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();

        primaryStage.setScene(scene);
        primaryStage.show();

        GameWindowController gameWindowController = loader.getController();
        gameWindowController.init(walletManager);
    }

    //EFFECTS: opens window with instructions on it
    @FXML
    void instructions(MouseEvent event) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Instructions");
        a.setHeaderText("Instructions");
        a.setContentText(INTRO_TEXT);
        a.show();
    }

    //EFFECTS: provides warning screen and initiates a new save call
    @FXML
    void newGameButtonFunction(MouseEvent event) {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION);
        a.setTitle("WARNING");
        a.setHeaderText("Your previous save will be overwritten");
        a.setContentText("Are you okay with this?");

        Optional<ButtonType> result = a.showAndWait();
        if (result.get() == ButtonType.OK) {
            newSave();
        }
    }

    //EFFECTS: quits game
    @FXML
    void quit(MouseEvent event) {
        System.exit(1);
    }
}
