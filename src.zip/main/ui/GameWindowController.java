package ui;

import exceptions.BlownUpException;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Card;
import model.Hand;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

//Game Window Scene
public class GameWindowController {

    @FXML Text playerHandTitle;
    @FXML Text dealerHandTitle;
    @FXML ListView playerHandList;
    @FXML ListView dealerHandList;
    @FXML Button hit;
    @FXML Button stand;
    @FXML Button total;
    @FXML Button contButton;
    @FXML Text nameText;
    @FXML Text balanceText;

    WalletManager walletManager;
    Hand playerHand;
    Hand dealerHand;

    String result;

    //MODIFIES: this
    //EFFECTS: update name and balance in this scene, play shuffle sound effect and start game
    //source: http://tutorials.jenkov.com/javafx/listview.html#adding-items-to-a-listview (ListView manipulation)
    public void init(WalletManager initWalletManager) {
        walletManager = initWalletManager;
        nameText.setText("Name: " + walletManager.wallet.getName());
        balanceText.setText("Balance: " + walletManager.wallet.getBalance());

        playSound("./data/cardShuffle.wav");

        contButton.setVisible(false);

        playerHandList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        dealerHandList.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        playerHand = new Hand();
        dealerHand = new Hand();
        playerHand.initializeHand();
        dealerHand.initializeHand();
        for (Card c : playerHand.cardList) {
            playerHandList.getItems().add(playerHand.toString(c));
        }
        dealerHandList.getItems().add(dealerHand.toString(dealerHand.getCardInList(0)));
        dealerHandList.getItems().add("Unknown");
    }

    //EFFECTS: plays draw card sound effect
    //source: https://stackoverflow.com/questions/6045384/playing-mp3-and-wav-in-java (plays sound)
    void playSound(String path) {
        AudioInputStream audioInputStream = null;
        try {
            audioInputStream = AudioSystem.getAudioInputStream(
                    new File(path));
            Clip shuffleClip = AudioSystem.getClip();
            shuffleClip.open(audioInputStream);
            shuffleClip.start();
        } catch (UnsupportedAudioFileException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    //EFFECTS: disables controls and adds continue button, also initiates dealer turn
    void endGame(Boolean blewUp) {
        hit.setVisible(false);
        stand.setVisible(false);
        total.setVisible(false);
        contButton.setVisible(true);
        boolean dealerBlewUp = false;

        dealerHandList.getItems().set(1, dealerHand.toString(dealerHand.getCardInList(1)));
        if (!blewUp) {
            while (dealerHand.getTotal() < 17) {
                try {
                    dealerHand.drawCard();
                } catch (BlownUpException e) {
                    dealerBlewUp = true;
                } finally {
                    dealerHandList.getItems().add(dealerHand.toString(
                            dealerHand.cardList.get(dealerHand.cardList.size() - 1)));
                }
            }
        }
        calculateWinner(blewUp, dealerBlewUp);
    }

    //MODIFIES: this
    //EFFECTS: calculates if player won or lost and changes wallet balance depending on win or loss
    void calculateWinner(Boolean playerBlewUp, Boolean dealerBlewUp) {
        if ((!playerBlewUp && playerHand.getTotal() > dealerHand.getTotal()) || dealerBlewUp) {
            result = "Win";
            walletManager.wallet.changeBalance("Win");
        } else if (playerHand.getTotal() < dealerHand.getTotal() || playerBlewUp) {
            result = "Lose";
            walletManager.wallet.changeBalance("Lose");
        } else {
            result = "Tie";
        }
    }

    //MODIFIES: this
    //EFFECTS: draws a card for the player and ends game if player has more than 21 in hand
    @FXML
    void playerHits() {
        try {
            playerHand.drawCard();
        } catch (BlownUpException e) {
            endGame(true);
        } finally {
            playSound("./data/cardSlide1.wav");
            playerHandList.getItems().add(playerHand.toString(playerHand.cardList.get(playerHand.cardList.size() - 1)));
        }
    }

    //EFFECTS: calculates and displays total of selected cards
    @FXML
    void calculateTotal() {
        int result = 0;

        ObservableList list = playerHandList.getSelectionModel().getSelectedIndices();
        for (Object o: list) {
            result += playerHand.cardList.get(Integer.parseInt(o.toString())).getValue();
        }
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Total");
        a.setHeaderText("Your total: ");
        a.setContentText(Integer.toString(result));
        a.show();
    }

    //EFFECTS: transitions to endGame phase
    @FXML
    void playerStands() {
        endGame(false);
    }

    //EFFECTS: transitions to results screen
    @FXML
    void contPressed(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("ResultWindow.fxml"));
        Parent root = (Parent) loader.load();
        Scene scene = new Scene(root);

        Stage primaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();

        primaryStage.setScene(scene);
        primaryStage.show();

        ResultWindowController resultWindowController = loader.getController();
        resultWindowController.init(walletManager, result,
                playerHand.getTotal(), dealerHand.getTotal());
    }
}
