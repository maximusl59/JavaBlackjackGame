package ui;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        launch();
    }

    //source: https://www.youtube.com/watch?v=XCgcQTQCfJQ&feature=youtu.be (loading scenes)
    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("StartMenu.fxml"));
        AnchorPane root = (AnchorPane) loader.load();

        Scene scene = new Scene(root);

        primaryStage.setTitle("Blackjack Game");
        primaryStage.getIcons().add(new Image("https://cdn2.iconfinder.com/data/icons/metro-ui-dock/512/Java.png"));

        primaryStage.setScene(scene);
        primaryStage.show();

        StartMenuController startMenuController = loader.getController();
        startMenuController.init();
    }
}
