package ui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

import java.io.IOException;

//Result Window Scene
public class ResultWindowController extends Menu {

    @FXML Text resultText;
    @FXML Text scoreText;

    @FXML Button newGameButton;
    @FXML Button instructionsButton;
    @FXML Button playAgainButton;
    @FXML Button quitButton;

    //MODIFIES: this
    //EFFECTS: displays win or loss text depending on result and the scores, also saves wallet
    void init(WalletManager initWalletManager, String status, int pscore, int dscore) {
        walletManager = initWalletManager;

        if (status.equals("Win")) {
            resultText.setText("You WON!");
        } else if (status.equals("Lose")) {
            resultText.setText("You Lost...");
        } else if (status.equals("Tie")) {
            resultText.setText("You tied.");
        }

        walletManager.saveWallet();
        scoreText.setText(pscore + " to " + dscore);
        update();
    }

    //EFFECTS: provides warning screen and initiates a new save call
    @FXML
    void newGameButtonFunction(MouseEvent event) {
        super.newGameButtonFunction(event);
    }

    //EFFECTS: loads next game window
    @FXML
    void runGame(MouseEvent event) throws IOException {
        super.runGame(event);
    }

    //EFFECTS: opens window with instructions on it
    @FXML
    void instructions(MouseEvent event) {
        super.instructions(event);
    }

    //EFFECTS: quits game
    @FXML
    void quit(MouseEvent event) {
        super.quit(event);
    }

}
