package exceptions;

public class BlownUpException extends Exception {
}
